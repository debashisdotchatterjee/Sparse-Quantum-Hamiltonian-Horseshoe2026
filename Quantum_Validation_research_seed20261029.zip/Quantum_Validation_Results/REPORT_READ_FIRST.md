# Quantum Hamiltonian empirical-validation output

**Status:** This package records simulation results and diagnostic checks. It is NOT a formal proof or a claim of new empirical discoveries before external verification.

## Theorem-to-experiment mapping

| Paper statement | Numerical experiment | What is / is not tested |
|---|---|---|
| Lemma: exact commutator score and curvature | Pauli score + Taylor remainder | Matrix exponentials and Frechet derivatives tested; not a proof for arbitrary settings |
| Theorems: restricted observability / diagonal Pauli design | Score heatmap, min singular values | Constructive 3-qubit realization and stability near zero |
| Theorem: observational symmetry no-go | X-only theta vs -theta | Exact identical Born probabilities; Y resolves sign |
| Theorems: N^-1/4 information singularity, quartic horseshoe law | One-qubit replicated binomial data + exact quadrature | Scaling and discretized TV to random quartic law; cannot test mathematical TV convergence exhaustively |
| Theorem: sparse fractional posterior contraction | 5 independent noncommuting X/Z blocks; and exact 2D factor at theorem's tau_N | Fixed-scale benchmark PLUS a separate theorem-scale active-block stress test; no simulation proves asymptotic contraction |
| Theorem: BvM and coverage | Fixed-dimensional 2-parameter Hamiltonian | Nonzero truth, fixed global scale, regular identified experiment |
| Real-data opportunity | Public 51-ion trapped-ion data | Inventory and optionally descriptive Neel magnetization; **NO** full quantum Hamiltonian fitting |

## Critical limitations

1. The simulation does not verify 51-ion coherent Hamiltonian learning; raw calibration and randomized settings need a dedicated forward model.
2. The high-dimensional theorem specifies tau_N=(pN)^-4, extremely concentrated at realistic N; practical fixed-tau methods are a different regime. An additional exact log-grid quadrature tests the theorem-scale posterior on the active two-coordinate factor of a ten-parameter product-block model. This is not a full 10D posterior validation.
3. MLE, ridge, lasso use prespecified penalty strengths, not fully cross-validated tuning; conclusions must not be portrayed as universal benchmarking superiority.
4. The regular BvM and quartic examples use different priors/true parameters; do not combine their assumptions.
5. The posterior is evaluated via discretized quadrature. Numerical grid and Monte Carlo errors persist. No significance or equivalence conclusion is implied by a small number of replicates.
6. Visibility is known; the hardware includes SPAM errors and possible dissipative (Lindbladian) dynamics that the simple model omits.

## Methods and reproducibility

All simulated measurements are independent binomial / Bernoulli shots under exact analytic or finite-dimensional matrix-exponential Born probabilities. Random seeds and configuration are recorded in `manifest.json`. Each numerical table has CSV and (where possible) LaTeX outputs. Plots are PNG/PDF in `figures/`.

## References for real data

- Kraft, T. et al., *Bounded-Error Quantum Simulation via Hamiltonian and Lindbladian Learning*, Physical Review X, DOI: https://doi.org/10.1103/s96t-n8tx.
- Dataset from Joshi, Kranzl, Franke, Roos and Blatt: https://doi.org/10.5281/zenodo.17750419.
- Hardware spin-neutrino quantum experiment and raw counts: https://doi.org/10.5281/zenodo.20109219.
- Raw preparation/measurement counts: https://doi.org/10.5281/zenodo.10723401.

## Execution outcome

Completed: design, dark, shot, singular, sparse, theorem_tau, bvm, real.

Failed: None.
