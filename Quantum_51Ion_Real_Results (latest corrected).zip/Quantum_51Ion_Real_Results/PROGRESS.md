# Execution status (not scientific verification)

- **completed** — Dataset reconstruction and audit: 11 times, 1000 independently recorded 51-spin shots/time; t0 mismatch=0.0110; randomized RU basis metadata missing.
- **completed** — Independent-shot split and readout calibration: Random 70% train / 10% validation / 20% test shot splits; one outcome-independent ion per shot; t=0 calibration independent of time>0 fit.
- **completed** — Homogeneous and Tikhonov baselines: Uniform J=247.214 rad/s; selected Tikhonov-style lambda=100.
- **completed** — Fractional horseshoe posterior: 1300 retained posterior draws, alpha=0.8; valid independently selected one-site Born likelihood for restricted 51-ion XY model.
- **completed** — Posterior convergence and identifiability: Gauge invariance max discrepancy 0.00e+00; MCMC Rhat max 1.266. Rhat warning: further chains/longer sampling recommended.
- **completed** — Out-of-sample predictions and figures: Independent 2000 test shots; 11 figures; performance measured without ground truth Hamiltonian.
- **completed** — Early-time-to-late-time extrapolation: Independent refits restricted to 1–5 ms; forecast measured at 6–10 ms; early-fit tau Rhat=1.123.
- **completed** — Published-method scope audit: Same-data Tikhonov baseline computed; published H+L method accurately contextualized but not falsely represented as reproduced.
- **completed** — Archive and reproducibility manifest: CSV, TeX, figures, model-draws, provenance, methodological limitations and manifest produced.
