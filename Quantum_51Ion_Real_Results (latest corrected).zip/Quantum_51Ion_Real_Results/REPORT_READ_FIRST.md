# 51-ion real-data Bayesian analysis: execution report

## DATA

11 times, 1000 shots/time, 51 ions

## INFERENCE

horseshoe with 1300 retained samples

## FIT

        method  train_mean_negative_logscore  test_mean_negative_logscore  test_brier  test_shots
     Horseshoe                      0.659644                     0.660506    0.234730        2000
Tikhonov-style                      0.660444                     0.658963    0.234137        2000
   Homogeneous                      0.663626                     0.659763    0.234455        2000

## WARNING

This is restricted nearest-neighbor XY fitting; published 51-ion Hamiltonian has long-range couplings/dissipation.

## Provenance and claims

See data_provenance.json and COMPARISON_SCOPE_AND_LIMITATIONS.md. All plots and tables correspond to actual experimental Z-basis measurements. No 51-ion full Hamiltonian reconstruction is claimed.
